﻿using Common;
using HtmlAgilityPack;
using NLog;
using ProxyIpSchedule.Model;
using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;

namespace ProxyIpSchedule.Helper
{
    public class ProxyIpHelper
    {
        private static readonly Logger _logger = LogManager.GetCurrentClassLogger();
        private List<string> _proxyList = new List<string>();
        private List<string> LinkList = new List<string>();
        public void start()
        {
            _logger.Info("开始获取代理ip");
            //用5个线程去抓取数据  5*3=15页数据
            Task[] tk = new Task[11];
            int pageindex = 0;

            InitLinkList();
            List<string> Ip_urls = new List<string>(); 
            int index = tk.Length - 1;
            Ip_urls = Get_Urls();
            if (Ip_urls.Count <= 0)
                return;
            Console.WriteLine($"{DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")} Ip_urls = {Ip_urls.Count}");
            for (int i = 0; i < index; i++)
            {
                PageParam pp = new PageParam(pageindex, 2);

                tk[i] = new Task(() =>
                {
                    GetNewIpList(Ip_urls,pp);
                    //get_ProxyIp_Tools(Ip_urls);

                });
                tk[i].Start();
                pageindex += 2;
            }
            tk[index] = new Task(() =>
            {
                List<string> urls = new List<string> { "http://api.foxtools.ru/v2/Proxy.txt?page=1", "https://www.proxy-list.download/api/v1/get?type=http", "https://www.proxy-list.download/api/v1/get?type=https", "http://www.66ip.cn/mo.php?tqsl=100" };
                get_ProxyIp_Tools(urls);
            });
            tk[index].Start();

            //Task.Factory.StartNew(StartRun);
            //设置20分钟超时
            Task.WaitAll(tk, (1000 * 60) * 30);
            _logger.Info($"共获取到:{_proxyList.Count}个有效ip");
            //运行目录
            var runPath = Path.GetDirectoryName(typeof(Program).Assembly.Location);
            if (_proxyList!= null && _proxyList.Count > 0)
            {
                File.WriteAllLines(runPath + "/newIp.txt", _proxyList);
                Task.Factory.StartNew(StartRun).Wait();
                Console.WriteLine($"任务完成: {_proxyList.Count}个有效ip。");
            }
        }



        private void GetNewIpList(List<string> urls, PageParam pp)
        {
            var index = pp.pageIndex;
            var size = pp.pageSize;
            for (int i = index; i < index + size; i++)
            {
                //高匿名代理
                var url = urls[i];
                try
                {
                    var html = NetHttpHelper.HttpGetRequest(url, out int status, 5000);
                    if (status == 200 && html != null)
                    {
                        string regex = @"<td>(\d+\.\d+\.\d+\.\d+)</td>\s+<td>(\d+)</td>";
                        if(url.Contains("nimadaili"))
                            regex = @"<td>(\d+\.\d+\.\d+\.\d+):(\d+)</td>";
                        Match mstr = Regex.Match(html, regex);
                        while (mstr.Success)
                        {
                            if (mstr.Groups[1].Value.Contains("."))
                            {
                                //proxyIp.Add(mstr.Groups[1].Value + ":" + mstr.Groups[2].Value);

                                //检查ip有效性
                                Proxy px = new Proxy(mstr.Groups[1].Value, Convert.ToInt32(mstr.Groups[2].Value));
                                if (checkVaild(px))
                                {
                                    Console.WriteLine(mstr.Groups[1].Value + ":" + mstr.Groups[2].Value);
                                    //写入列表 稍后一并写入文件
                                    _proxyList.Add(mstr.Groups[1].Value + ":" + mstr.Groups[2].Value);
                                }
                            }
                            mstr = mstr.NextMatch();
                        }
                    }

                    //HtmlDocument doc = new HtmlDocument();
                    //doc.LoadHtml(html);
                    //var table_tr = doc.DocumentNode.SelectNodes(".//table[@id='ip_list']/tr");
                    //if (table_tr != null)
                    //{
                    //    //第一个是标题 这里从第二个开始
                    //    for (int j = 1; j < table_tr.Count; j++)
                    //    {
                    //        var tr_child = table_tr[j].ChildNodes;
                    //        var ip_str = tr_child[3].InnerText;
                    //        var port_str = tr_child[5].InnerText;
                    //        var speed_html = tr_child[13].InnerHtml;
                    //        //提取速度
                    //        var regexStr = string.Format(" <{0}[^>]*?{1}=(['\"\"]?)(?<text>[^'\"\"\\s>]+)\\1[^>]*>", "div", "title");
                    //        Match TitleMatch = Regex.Match(speed_html, regexStr, RegexOptions.IgnoreCase);
                    //        string speed_text = TitleMatch.Groups["text"].Value;
                    //        speed_text = speed_text.Replace("秒", "");
                    //        int.TryParse(port_str, out int port);
                    //        float.TryParse(speed_text, out float speed);
                    //        //只提取速度<=2s的
                    //        if (speed <= 2)
                    //        {
                    //            //检查ip有效性
                    //            Proxy px = new Proxy(ip_str, port);
                    //            if (checkVaild(px))
                    //            {
                    //                //写入列表 稍后一并写入文件
                    //                _proxyList.Add(ip_str + "," + port_str);
                    //            }
                    //        }
                    //    }

                    //}
                }
                catch (Exception ex)
                {
                    //获取代理ip出错
                    _logger.Info("获取代理ip:" + url + " 出错");
                    _logger.Error(ex);
                }
            }
        }
        /// <summary>
        /// 检查ip有效性
        /// </summary>
        /// <param name="p"></param>
        /// <returns></returns>
        private bool checkVaild(Proxy p)
        {
            var flag = false;
            try
            {
                _logger.Debug($"正在检查IP:{p.ip}:{p.port}");
                var rand = new Random();
                var n = rand.Next(100000);
                var html = NetHttpHelper.HttpGetRequest("http://www.baidu.com", out int status, 2000, p.ip, p.port);
                if (status == 200)
                {
                    //检查ip是否有效
                    if (html.Contains("百度"))
                    {
                        flag = true;
                        _logger.Debug($"IP:{p.ip}:{p.port} 有效");
                    }
                }
            }
            catch (Exception)
            {
            }
            return flag;
        }


        private void get_ProxyIp_Tools(List<string> urls, string regex = @"(\d+\.\d+\.\d+\.\d+):(\d+)")//获取代理 IP
        {
            int count = urls.Count;
            Task[] task = new Task[count];
            for (int page = 0; page < count; page++)
            {
                string Url = urls[page];//"http://api.foxtools.ru/v2/Proxy.txt?page=1";
                task[page] = new Task(() =>
                {
                    //get_ProxyIp_Tools(Ip_urls);
                    try
                    {
                        string html = NetHttpHelper.HttpGetRequest(Url, out int status, 5000);//HttpPost(Url, Encoding.Default);
                        if (!string.IsNullOrEmpty(html))
                        {
                            //string regex = @"(\d+\.\d+\.\d+\.\d+):(\d+)";
                            Match mstr = Regex.Match(html, regex);
                            while (mstr.Success)
                            {
                                if (mstr.Groups[1].Value.Contains("."))
                                {
                                    //proxyIp.Add(mstr.Groups[1].Value + ":" + mstr.Groups[2].Value);

                                    //检查ip有效性
                                    Proxy px = new Proxy(mstr.Groups[1].Value, Convert.ToInt32(mstr.Groups[2].Value));
                                    if (checkVaild(px))
                                    {
                                        Console.WriteLine(mstr.Groups[1].Value + ":" + mstr.Groups[2].Value);
                                        //写入列表 稍后一并写入文件
                                        _proxyList.Add(mstr.Groups[1].Value + ":" + mstr.Groups[2].Value);
                                    }

                                }
                                mstr = mstr.NextMatch();
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        //获取代理ip出错
                        _logger.Info("获取代理ip:" + Url + " 出错");
                        _logger.Error(ex);
                    }
                });

                task[page].Start();
            }
        }


        private List<string> Get_Urls()
        {
            List<string> Urls = new List<string>();

            string Url = "https://www.zdaye.com/dayProxy/ip/330139.html";
            try
            {
                string url = $"https://www.zdaye.com/dayProxy/{DateTime.Now.Year}/{DateTime.Now.Month}/1.html"; ;
                string info = NetHttpHelper.HttpGetRequest(url, out int status, 3000);

                if (status == 200 && !string.IsNullOrEmpty(info))
                {
                    string regex = @"<a href=""/dayProxy/ip/(\d+)";
                    Match mstr = Regex.Match(info, regex);
                    if (mstr.Success)
                    {
                        //Console.WriteLine("url= " + mstr.Value);
                        Url = "https://www.zdaye.com" + mstr.Value.Split('"')[1];
                        Console.WriteLine("Url= " + Url);

                        for (int i = 1; i <= 10; i++)
                        {
                            string _url = Url + "/" + i.ToString() + ".html";
                            Urls.Add(_url);
                            _url = "http://www.nimadaili.com/https/" + i.ToString() + "/";
                            Urls.Add(_url);

                            //Console.WriteLine("Url= " + _url);
                            //http://www.nimadaili.com/gaoni/1/
                            //https://www.dieniao.com/FreeProxy/2.html
                            //https://list.proxylistplus.com/Fresh-HTTP-Proxy-List-
                            //http://www.ip3366.net/free/?stype=2&page=
                            //http://www.89ip.cn/index_
                        }
                    }
                }
            }
            catch
            {
                Console.WriteLine("get www.zdaye.com ip error.");
            }
            return Urls;
        }


        private void InitLinkList()
        {
            LinkList = new List<string>();
            LinkList.Add("http://dd.ma/69cOLaPl");
            LinkList.Add("http://dd.ma/vglolbnx");
            LinkList.Add("http://dd.ma/H5mXYfZ7");
            LinkList.Add("http://dd.ma/GXZ0iQ4C");
            LinkList.Add("http://dd.ma/9WKfhNtA");
            LinkList.Add("http://dd.ma/ckREuWnv");
            LinkList.Add("http://dd.ma/BpZfdTC8");
            LinkList.Add("http://dd.ma/W3VFDyJ6");
            LinkList.Add("http://dd.ma/1RCas5HJ");
            LinkList.Add("http://dd.ma/tjBPlvIA");
            LinkList.Add("http://dd.ma/W3VFDyJ6");
            LinkList.Add("http://dd.ma/eoK2TJKh");
            LinkList.Add("http://dd.ma/JBhKrGHF");
            LinkList.Add("http://dd.ma/PkcUmFGu");
            LinkList.Add("http://dd.ma/wMOsV3Uh");
            LinkList.Add("http://dd.ma/1d0tiId4");
            LinkList.Add("http://dd.ma/vglolbnx");
            LinkList.Add("http://dd.ma/1Ob7esyt");
            LinkList.Add("http://dd.ma/AUFUehRt");
            LinkList.Add("http://dd.ma/aMKrTX1y");
            LinkList.Add("http://dd.ma/lpHMP3Yr");
            LinkList.Add("https://blog.csdn.net/Cool2Feel/article/details/116832066");
            LinkList.Add("https://www.toutiao.com/a1700236994845700");
            LinkList.Add("https://blog.csdn.net/Cool2Feel/article/details/116841174");
        }

        private void StartRun()
        {
            //int proxNum = ProxyList.Count - 1;
            Console.WriteLine("Start AutoVisiteLink!");
            int index = 0;
            int p = 0;
            List<string> proxyList = _proxyList;
            int counts = proxyList.Count;

            while (proxyList.Count > 0 && counts > 0)
            {
                try
                {
                    if (index >= LinkList.Count)
                    {
                        index = 0;
                        p++;
                        counts = _proxyList.Count;
                    }
                    if (p >= _proxyList.Count)
                        p = 0;
                    string link = LinkList[index];
                    string item = _proxyList[p];
                    //var temp = new WebProxy(item.Address,item.BypassProxyOnLocal);
                    //webBrowser1.Navigate(s[txtBxNum]);
                    Console.WriteLine("crute link :" + link + "  Index = " + index);
                    ProxyWebResponse(item, link);
                    Thread.Sleep(300);
                    index++;
                }
                catch { }
            }

        }


        private void ProxyWebResponse(string item, string link)
        {
            try
            {
                System.GC.Collect();
                var temp = new Proxy(item.Split(':')[0], Convert.ToInt32(item.Split(':')[1]));

                var html = NetHttpHelper.HttpGetRequest(link, out int status, 3000, temp.ip, temp.port);
                //Console.WriteLine($"代理Ip浏览:{item.Address}");
                if (status == 200)
                {
                    //检查ip是否有效
                    if (html.Length > 0)
                    {
                        _logger.Debug($"Url: {link} Proxy IP:{temp.ip}:{temp.port} Look.");
                    }
                }
            }
            catch
            {
                return;
            }
        }


    }
}


